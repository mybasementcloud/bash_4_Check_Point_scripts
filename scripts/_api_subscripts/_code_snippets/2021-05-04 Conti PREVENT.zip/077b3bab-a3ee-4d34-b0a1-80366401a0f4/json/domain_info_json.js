function getDomainInfoJSON()
{
var DomainInfoJSON =
[];
return DomainInfoJSON;
}