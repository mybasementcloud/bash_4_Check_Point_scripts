function f5128_1620132741069()
{
var procJSON =
{
"f_c":[],
"f_r":[],
"f_d":[],
"f_m":[],
"f_a":[],
"f_i":[],
"u_a":[],
"s_a":[],
"d_a":[],
"l_a":[],
"r_a":[],
"r_m":[{"k":"HKLM\\system\\controlset001\\services\\bam\\state\\usersettings\\s-1-5-21-1401510904-3903672865-1554255095-1001","v":"\\device\\harddiskvolume4\\windows\\system32\\conhost.exe","da_o":"","da_n":"","o":"Set Value Key, Query Value Key","s":1,"t":1620132741093}],
"i_a":[],
"e_a":[],
"i_p":[],
"a_a":[],
"n_a":[],
"c_a":[],
"m_e":[{"cat":"Modify Registry","d":"Adversaries may interact with the Windows Registry to hide configuration information within Registry keys, remove information as part of cleaning up, or as part of other techniques to aid in Persistence and Execution.","scr":1,"i":"skulls-1.png","events": [{"d":"Y21kLmV4ZSAoUElEOiA1MTI4KSBtb2RpZmllZCBIS0xNXHN5c3RlbVxjb250cm9sc2V0MDAxXHNlcnZpY2VzXGJhbVxzdGF0ZVx1c2Vyc2V0dGluZ3Nccy0xLTUtMjEtMTQwMTUxMDkwNC0zOTAzNjcyODY1LTE1NTQyNTUwOTUtMTAwMVxcZGV2aWNlXGhhcmRkaXNrdm9sdW1lNFx3aW5kb3dzXHN5c3RlbTMyXGNvbmhvc3QuZXhl","t":1620132741093}]},{"cat":"Execution through API","d":"Adversary tools may directly use the Windows application programming interface (API) to execute binaries. Functions such as the Windows API CreateProcess will allow programs and scripts to start other processes with proper path and argument parameters.","scr":2,"i":"skulls-2.png","events": [{"d":"Y21kLmV4ZSAoUElEOiA1MTI4KSBleGVjdXRlZCB3aXRoIGFyZ3VtZW50czogL2MgbmV0IHN0b3AgTVNTUUwkUFJPRlhFTkdBR0VNRU5UIC95","t":1620132741069}]},{"cat":"Command-Line Interface","d":"Command-line interfaces provide a way of interacting with computer systems and is a common feature across many types of operating system platforms. One example command-line interface on Windows systems is cmd, which can be used to perform a number of tasks including execution of other software. Command-line interfaces can be interacted with locally or remotely via a remote desktop application, reverse shell session, etc. Commands that are executed run with the current permission level of the command-line interface process unless the command includes process invocation that changes permissions context for that execution (e.g. Scheduled Task).","scr":3,"i":"skulls-3.png","events": [{"d":"Y21kLmV4ZSAoUElEOiA1MTI4KSBleGVjdXRlZCB3aXRoIGFyZ3VtZW50czogL2MgbmV0IHN0b3AgTVNTUUwkUFJPRlhFTkdBR0VNRU5UIC95","t":1620132741069}]},{"cat":"Scripting","d":"Adversaries may use scripts to aid in operations and perform multiple actions that would otherwise be manual. Scripting is useful for speeding up operational tasks and reducing the time required to gain access to critical resources. Some scripting languages may be used to bypass process monitoring mechanisms by directly interacting with the operating system at an API level instead of calling other programs. Common scripting languages for Windows include VBScript and PowerShell but could also be in the form of command-line batch scripts.","scr":3,"i":"skulls-3.png","events": [{"d":"Y21kLmV4ZSAoUElEOiA1MTI4KSBleGVjdXRlZCB3aXRoIGFyZ3VtZW50czogL2MgbmV0IHN0b3AgTVNTUUwkUFJPRlhFTkdBR0VNRU5UIC95","t":1620132741069}]}],
"b_i":[],
"amsi":[],
"wmi_g":[]
}
;
return procJSON;
}