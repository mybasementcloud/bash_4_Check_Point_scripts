function f4828_1620132745777()
{
var procJSON =
{
"f_c":[],
"f_r":[],
"f_d":[],
"f_m":[],
"f_a":[],
"f_i":[],
"u_a":[],
"s_a":[],
"d_a":[],
"l_a":[],
"r_a":[],
"r_m":[],
"i_a":[],
"e_a":[],
"i_p":[],
"a_a":[],
"n_a":[],
"c_a":[],
"m_e":[{"cat":"Dangerous Execution","d":"System processes, such as cmd.exe, are being executed. While these processes can be loaded legitimately, their use is relatively rare and is often used by malware.","scr":2,"i":"skulls-2.png","events": [{"d":"bmV0LmV4ZSAoUElEOiA0ODI4KSBleGVjdXRlZCB3aXRoIGFyZ3VtZW50czogIHN0b3AgUmVwb3J0U2VydmVyJFRQUyAveQ==","t":1620132745777}]},{"cat":"Service Stop","d":"Adversaries may stop or disable services on a system to render those services unavailable to legitimate users. Stopping critical services can inhibit or stop response to an incident or aid in the adversary's overall objectives to cause damage to the environment.","scr":4,"i":"skulls-4.png","events": [{"d":"bmV0LmV4ZSAoUElEOiA0ODI4KSBleGVjdXRlZCB3aXRoIGFyZ3VtZW50czogIHN0b3AgUmVwb3J0U2VydmVyJFRQUyAveQ==","t":1620132745777}]},{"cat":"Execution through API","d":"Adversary tools may directly use the Windows application programming interface (API) to execute binaries. Functions such as the Windows API CreateProcess will allow programs and scripts to start other processes with proper path and argument parameters.","scr":2,"i":"skulls-2.png","events": [{"d":"bmV0LmV4ZSAoUElEOiA0ODI4KSBleGVjdXRlZCB3aXRoIGFyZ3VtZW50czogIHN0b3AgUmVwb3J0U2VydmVyJFRQUyAveQ==","t":1620132745777}]}],
"b_i":[],
"amsi":[],
"wmi_g":[]
}
;
return procJSON;
}