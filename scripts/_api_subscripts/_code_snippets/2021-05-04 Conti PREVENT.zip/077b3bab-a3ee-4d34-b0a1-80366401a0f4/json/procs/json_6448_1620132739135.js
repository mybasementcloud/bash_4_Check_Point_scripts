function f6448_1620132739135()
{
var procJSON =
{
"f_c":[],
"f_r":[],
"f_d":[],
"f_m":[],
"f_a":[],
"f_i":[],
"u_a":[],
"s_a":[],
"d_a":[],
"l_a":[],
"r_a":[],
"r_m":[],
"i_a":[],
"e_a":[],
"i_p":[],
"a_a":[],
"n_a":[],
"c_a":[],
"m_e":[{"cat":"Execution through API","d":"Adversary tools may directly use the Windows application programming interface (API) to execute binaries. Functions such as the Windows API CreateProcess will allow programs and scripts to start other processes with proper path and argument parameters.","scr":2,"i":"skulls-2.png","events": [{"d":"Y29uaG9zdC5leGUgKFBJRDogNjQ0OCkgZXhlY3V0ZWQgd2l0aCBhcmd1bWVudHM6IDB4ZmZmZmZmZmYgLUZvcmNlVjE=","t":1620132739135}]}],
"b_i":[],
"amsi":[],
"wmi_g":[]
}
;
return procJSON;
}