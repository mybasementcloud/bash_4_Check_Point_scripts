function f10392_1620132737987()
{
var procJSON =
{
"f_c":[],
"f_r":[],
"f_d":[],
"f_m":[],
"f_a":[],
"f_i":[],
"u_a":[],
"s_a":[],
"d_a":[],
"l_a":[],
"r_a":[],
"r_m":[],
"i_a":[],
"e_a":[],
"i_p":[],
"a_a":[],
"n_a":[],
"c_a":[],
"m_e":[{"cat":"Execution through API","d":"Adversary tools may directly use the Windows application programming interface (API) to execute binaries. Functions such as the Windows API CreateProcess will allow programs and scripts to start other processes with proper path and argument parameters.","scr":2,"i":"skulls-2.png","events": [{"d":"Y29uaG9zdC5leGUgKFBJRDogMTAzOTIpIGV4ZWN1dGVkIHdpdGggYXJndW1lbnRzOiAweGZmZmZmZmZmIC1Gb3JjZVYx","t":1620132737987}]}],
"b_i":[],
"amsi":[],
"wmi_g":[]
}
;
return procJSON;
}