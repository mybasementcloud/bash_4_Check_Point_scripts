function getInjectionJSON()
{
var InjectionJSON =
[];
return InjectionJSON;
}