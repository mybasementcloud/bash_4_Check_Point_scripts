function getCountryInfoJSON()
{
var CountryInfoJSON =
[];
return CountryInfoJSON;
}