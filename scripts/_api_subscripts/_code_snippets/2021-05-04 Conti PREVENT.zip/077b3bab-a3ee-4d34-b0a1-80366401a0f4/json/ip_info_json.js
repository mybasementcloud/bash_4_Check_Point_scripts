function getIPInfoJSON()
{
var IPInfoJSON =
[];
return IPInfoJSON;
}