alias goapi='cd /var/cli_api_ops'
alias goapiwip='cd /var/cli_api_ops.wip'
alias goexportwip='cd /var/cli_api_ops.wip/export_import'
