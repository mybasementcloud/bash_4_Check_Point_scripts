psql_client monitoring postgres

begin;
delete from hitcount;
end;
\q

