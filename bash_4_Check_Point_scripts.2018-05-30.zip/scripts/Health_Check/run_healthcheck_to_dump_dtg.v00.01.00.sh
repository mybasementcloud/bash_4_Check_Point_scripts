#!/bin/bash
#
# SCRIPT for BASH to generate a dump folder based on the current time and date
# run healthcheck script, and dump result files into the dtg folder
#
ScriptVersion=00.01.00
ScriptDate=2018-03-29
#

export BASHScriptVersion=v00x01x00

#points to where jq is installed
#export JQ=${CPDIR}/jq/jq

export DATE=`date +%Y-%m-%d-%H%M%Z`
export DATEDTG=`date +%Y-%m-%d-%H%M%Z`
export DATEDTSG=`date +%Y-%m-%d-%H%M%S%Z`
export DATEYMD=`date +%Y-%m-%d`

echo 'Date Time Group   :  '$DATE
echo 'Date (YYYY-MM-DD) :  '$DATEYMD
echo

# WAITTIME in seconds for read -t commands
export WAITTIME=60

export outputpathroot=/var/upgrade_export/dump
#export outputpathbase=$outputpathroot/$DATE
export outputpathbase=$outputpathroot/$DATEDTG
#export outputpathbase=$outputpathroot/$DATEYMD

if [ ! -r $outputpathroot ] 
then
    mkdir $outputpathroot
fi
if [ ! -r $outputpathbase ] 
then
    mkdir $outputpathbase
fi

echo 'Created folder :  '$outputpathbase
echo

./healthcheck

export hclogfilebase=/var/log/$(hostname)-health_check-*

echo
echo 'Moving healthcheck log files to '$outputpathbase
echo
mv $hclogfilebase $outputpathbase

echo
ls -al $outputpathbase
echo
